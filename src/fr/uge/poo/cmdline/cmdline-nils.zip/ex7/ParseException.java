package fr.uge.poo.cmdline.ex7;

public class ParseException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
