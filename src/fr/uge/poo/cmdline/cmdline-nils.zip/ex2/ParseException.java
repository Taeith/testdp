package fr.uge.poo.cmdline.ex2;

public class ParseException extends RuntimeException {

}
