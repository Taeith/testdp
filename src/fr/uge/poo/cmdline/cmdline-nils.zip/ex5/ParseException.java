package fr.uge.poo.cmdline.ex5;

public class ParseException extends RuntimeException {

}
