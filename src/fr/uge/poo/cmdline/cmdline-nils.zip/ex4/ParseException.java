package fr.uge.poo.cmdline.ex4;

public class ParseException extends RuntimeException {

}
