package fr.uge.poo.cmdline.ex6;

public class ParseException extends RuntimeException {

}
